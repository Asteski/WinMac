
# INFORMATION

Author:     https://github.com/imshvc (Nurudin Imsirovic)
Project:    Windows Modern Cursors v2
Version:    v2.0.0
Repository: https://github.com/imshvc/windows-cursors-modern
Updated:    2025-02-19 03:23 PM +0200

# README

Improved Aero for DPI and Dark Mode.

This bundle contains the following cursor scales:

   x1 |   32 px
   x2 |   64 px
   x3 |   96 px
   x4 |  128 px
   x5 |  160 px

# INSTALLATION

1. Copy the "windows" folder to the "C:" drive
2. Apply the "scheme.reg" file
3. Open "main.cpl" and choose any of the "Windows Modern v2" cursors
