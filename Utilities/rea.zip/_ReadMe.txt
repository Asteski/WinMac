Instructions:
1) Mount ISO and install Windows
2) While installing windows - Select i don't have product key
3) Make sure that you are connected to the internet
4) Copy Activator file in desktop
5) Run as administrator
6) Type "B"

DONE!
 

You can always thank us here:  www.TheWindowsForum.com /  www.ThumperDC.com